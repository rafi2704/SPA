
  # Kulinarny Portal Przepisów

  This is a code bundle for Kulinarny Portal Przepisów. The original project is available at https://www.figma.com/design/cFuIfrbEN7TJSxoPFEIfTx/Kulinarny-Portal-Przepis%C3%B3w.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  